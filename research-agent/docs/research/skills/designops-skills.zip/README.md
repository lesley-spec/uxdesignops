# Design Thinking skills (impact.com UX DesignOps)

Portable [Agent Skills](https://agentskills.io/specification) for the [UX DesignOps FigJam](https://www.figma.com/board/slhZ9uzMTmaekjmbEosyzb/UX-DesignOps).

Canonical source: `.agents/skills/` (open standard). Cursor discovers them via symlinks in `.cursor/skills/`.

## How these skills answer

**Lead with the insight, not the evidence.** What someone gets back from a skill
is short: the finding, what it changes, and the next thing to do. A few lines,
not a report — they came for a decision, not a download.

**Offer the depth, don't deliver it.** Close with one specific follow-up they can
run — *"want the evidence trail behind finding 2?"* — not a menu of five. The
detail stays available; it does not arrive unasked.

**A number earns its place by changing a decision.** Everything else goes in the
artifact — the claim, the card, the one-pager — where it can be found when it is
needed.

This is a constraint on the **output**, not on the rigour. The evidence trails,
disconfirming evidence and confidence grades still get produced and still get
written down. They just do not all get said.

## Start here

**One name to remember: `ux-research-master`.** Everything else it finds for you.

```bash
curl -fsSL https://lesley-spec.github.io/uxdesignops/skills/install-all.sh | bash
```

That installs 30 pipeline skills (32 folders), the eight `/ux-*` starter
prompts in Cursor and Claude Code, and a routing block in `CLAUDE.md` /
`AGENTS.md`. After it, type `/ux` for the menu — or just describe what you're
working on and the right skill loads itself.

| Skill | Use when |
|---|---|
| `ux-research-master` | **Front door.** Installs the pack, routes any message to the right skill, owns the `/ux-*` starter prompts. Start here. |
| `design-thinking-ux` | Guided run Empathize → Test: intake questions, then the orchestrator **invokes** the phase skills (research, write-spec / tickets, ideate, prototype shells, test-plan). |
| `ux-research` | Guided **research** run: intake → the Frame → study plan → instruments. |
| `ux-install-all-skills` | The install step on its own — new machine, or the pack went missing. `ux-research-master` calls it for you. |

### The starter prompts

After install it asks *"How can UX research help you today?"* and offers these
eight. Each is also a slash command, project and global, in Cursor and Claude
Code.

| | Prompt | Skill |
|---|---|---|
| `/ux-context` | *"What do we already know about this?"* | `user-context` |
| `/ux-personas` | *"Who am I designing for, and what are they trying to get done?"* | `user-personas` |
| `/ux-ideate` | *"Give me a few directions to explore for this problem."* | `ideate` |
| `/ux-critique` | *"Do these mocks actually solve the problem we wrote down?"* | `ux-critique` |
| `/ux-heuristics` | *"Run a heuristic review on this."* | `heuristic-review` |
| `/ux-persona-check` | *"Walk a user through this before I put it in front of real people."* | `persona-check` |
| `/ux-intake` | *"I need research on this — what's the fastest way to a real answer?"* | `research-intake` |
| `/ux-adoption` | *"We shipped it. Did it make any difference?"* | `adoption-check` |

`/ux` on its own prints the menu; `/ux <anything>` routes it. The other 22
skills route from plain chat — they just don't take up a slot on the menu.

Full routing table: [`ux-research-master/references/routing.md`](ux-research-master/references/routing.md).

Phase skills below still work on their own, and naming one runs just that one.

## Research engine (runs alongside the five stages)

Not a sixth stage. A loop with its own front door and its own cadence: a request
gets routed, becomes a study, the study gets instrumented, the finding becomes a
claim, and the claims get re-checked. It touches Empathize, Define and Test, so
it sits here rather than inside any one of them.

```
research-intake ──routed──→ research-planner ──┬──→ research-builder
                                               └──findings──→ user-context (record)
                                                                    ↑
                                                       frame-maintenance (quarterly)
```

| Skill | Use when |
|---|---|
| `user-context` | What do we know about X · is this hypothesis supported · where are the blindspots — reads **and** writes the Frame |
| `research-intake` | Someone files a research request: four questions, two checks, one route (MICRO 48h / SPRINT 1–2w / DEEP 4w+) |
| `research-planner` | Routed request → a study worth running: sub-questions, sample, probes, go/no-go thresholds, 3-participant rigor pass |
| `research-builder` | The instruments around the study — PostHog dashboard **first**, audience from real usage, Pendo guide, interview guide |
| `frame-maintenance` | Quarterly, or when someone asks if the Frame can still be trusted: what's stale, what to retire, what to research next |
| `adoption-check` | After something ships: did the measure move, was it bigger than normal variation, and does the claim still hold |
| `pendo-guide-strategy` | Before building any Pendo guide — warm targeting, benefit-first copy, single step, conversion goals through to participation |
| `user-personas` | The six reference personas with per-claim confidence and the gaps the set refuses to paper over |
| `persona-check` | Walk a persona through a design as a task before real participants see it — hypotheses, never findings |
| `ux-research` | Master research orchestrator — routes intake → Frame → planning → the Empathize pack, one child at a time |

**Human gate:** Everything here drafts. A human finalises the ticket, the screener, the guide, and anything customer-facing (never publish a Pendo guide to live traffic unprompted).
## Empathize (stage 1)

| Skill | Use when |
|---|---|
| `user-research` | Deep-dive a finding, design a study, or decide if a problem is worth solving |
| `research-synthesis` | Triangulate across PostHog + Pendo + Dovetail (+ Outset/Freshdesk) |
| `synthesize-research` | Affinity / theme a **single** corpus (one Dovetail project, one interview set) |
| `data-analyze` | Ad-hoc PostHog or Pendo quantitative questions (FigJam label was `data:analyze`) |

**Agent (scheduled):** Research Insight Monitor in `research-agent/` — on-demand layer is the skills above.

**Human gate:** Designer confirms the problem is worth solving. Skills recommend; they do not decide.

## Define (stage 2)

| Skill | Use when |
|---|---|
| `write-spec` | Confirmed research → one-pager + linked UX Epic / Confluence (Problem Definition Generator) |
| `anti-sycophancy` | Pressure-test framing before Designer + PM review |
| `brand-operator-ux-persona` | Brand-side JTBD / operator lens |
| `creator-affiliate-ux-persona` | Partner / creator-affiliate lens |
| `design-system` | Point specs at styleguide + component library |

**Human gate:** Designer signs off when happy, then chats with a PM before Ideate. `write-spec` drafts and publishes only after designer confirm; it does not auto-advance.

## Ideate (stage 3)

| Skill | Use when |
|---|---|
| `ideate` | Framing → ideation brief + tool routing + starter directions (Solution Ideator) |
| `ux-critique` | Coverage matrix: mocks vs one-pager / PRD / epic / tickets / notes (UX Critique) |
| `heuristic-review` | Expert usability pass — ten classic heuristics plus two-sided consequence, money legibility, role truth, scale asymmetry |
| `prototype-handoff` | Designer happy with mocks → Prototype pack (after `ux-critique`) |
| `brand-operator-ux-persona` | Brand lens on concepts |
| `creator-affiliate-ux-persona` | Partner / creator-affiliate lens on concepts |
| `design-system` | Before on-brand mocks (Figma Make / Cursor) |

**Agents (on-demand):** Solution Ideator (`ideate`) · UX Critique (`ux-critique`).

**Intake:** One-pager or detailed PRD preferred; epic, tickets, Granola/meeting notes, or chat paste OK (label framing gaps).

**Human gate:** Do not auto-advance to Prototype. Run `ux-critique` before `prototype-handoff`. Designer confirms the handoff pack.

## Prototype (stage 4)

| Skill | Use when |
|---|---|
| `ux-prototyping` | Preferred Prototype entry — any harness (Cursor, Claude, Figma Make): live Brand or Partner preview, then GitHub Pages on the designer’s account |
| `brand-prototype` | One prompt → clone Brand UI shell, `npm install`, start Vite (Cursor preferred) |
| `partner-prototype` | One prompt → clone Partner UI shell, `npm install`, start Vite (Cursor preferred) |
| `design-system` | After shell is up, when mapping mocks to Styleguide V2 |

**Agent (on-demand):** Prototype Scaffolder — `ux-prototyping` (wraps `brand-prototype` / `partner-prototype`). The master skill `design-thinking-ux` invokes `ux-prototyping` after Ideate handoff.

**How it works:** `ux-prototyping` detects the harness and stays there. Cursor / Claude Code / Copilot: `ensure-harness.sh` then Brand/Partner `bootstrap.sh` (localhost). Figma Make: clone or Make-file preview. Claude chat: live artifact preview. GitHub Pages repos are created under **the designer’s GitHub login**, not the template account.

**Enforcement:** In the `design-thinking-ux` Prototype phase, only `ux-prototyping` may set up a prototype (Brand or Partner shell). No from-scratch Vite/Next apps. Valid in Cursor, Claude, and Figma Make.

**Harness:** Finish Prototype in the current tool. Shell harnesses auto-install Node and start Vite. Make and Claude chat use that harness’s live preview — do not bounce designers to Cursor.

**Human gate:** Designer owns fidelity and interaction after the shell is running.

## Test (stage 5)

| Skill | Use when |
|---|---|
| `test-plan` | Prototype ready → synthetic pre-flight + Outset/Maze study draft (Test Plan Generator) |
| `accessibility-review` | Synthetic a11y pre-test before unmoderated Maze or recruiting |
| `ux-critique` | Re-check prototype coverage vs one-pager/PRD/epic before sessions (pre-test mode) |
| `test-loopback` | After sessions → publish Verified findings to Confluence/Jira → Empathize input |
| `user-research` | Study-plan depth, recruitment gaps, or post-session gate brief |
| `synthesize-research` | Affinity / theme a completed test corpus (feeds `test-loopback`) |
| `brand-operator-ux-persona` | Brand-side task realism in test scripts |
| `creator-affiliate-ux-persona` | Partner-side task realism in test scripts |

**Agent (on-demand):** Test Plan Generator (`test-plan`).

**Tools:** Outset MCP (`https://api.outset.ai/mcp/`) to create draft studies · `OUTSET_API_KEY` to list studies · Maze · Pendo · Confluence · Jira · Figma.

**Human gate:** UX researcher reviews and publishes the test plan. After sessions, sit with the designer on where users got stuck and whether to iterate mocks. Findings loop back to Empathize — do not treat AI synthesis as verified research.

## Install in any harness

**Easiest (Cursor / Claude Code):** say `use ux-install-all-skills`. The agent installs all 19 pipeline skills into this project **and** globally (`~/.cursor/skills`, `~/.claude/skills`) so the next project works too.

**Download the pack:** [designops-skills.zip](https://lesley-spec.github.io/uxdesignops/skills/designops-skills.zip) · [Skills page](https://lesley-spec.github.io/uxdesignops/skills/)

One-command install (no chat required):

```bash
curl -fsSL https://lesley-spec.github.io/uxdesignops/skills/install-all.sh | bash
```

Harness-only (project folder, no global copy) — Cursor example:

```bash
curl -fsSL https://lesley-spec.github.io/uxdesignops/skills/install.sh | bash -s -- cursor .
```

Replace `cursor` with `claude` or `agents` for Claude Code or Copilot/Codex.

| Harness | Typical path |
|---|---|
| Cursor | `.cursor/skills/<name>/` (symlinked locally; `.cursor/` is gitignored) |
| Claude Code / Claude | `.claude/skills/<name>/` (pipeline skills, tracked in this repo) |
| Codex / VS Code Copilot | `.agents/skills/<name>/` |
| Figma Agent | Project or org skills that point at the same `SKILL.md` folders |

```bash
# Example: Claude Code (single skill)
mkdir -p .claude/skills
ln -sfn ../../.agents/skills/write-spec .claude/skills/write-spec
```

Invoke by name, e.g. “use `ux-install-all-skills`” to install the pack, “use `design-thinking-ux`” for the full pipeline, or a phase skill: “use `write-spec` on this confirmed finding” / “use `ideate` on UX-1234” / “run `ux-critique` before handoff” / “use `ux-prototyping`” / “use `brand-prototype`” / “use `partner-prototype`” / “use `test-plan` on [prototype link]”.

```bash
# Prototype shells (also symlink for Cursor)
ln -sfn ../../.agents/skills/ux-prototyping .cursor/skills/ux-prototyping
ln -sfn ../../.agents/skills/brand-prototype .cursor/skills/brand-prototype
ln -sfn ../../.agents/skills/partner-prototype .cursor/skills/partner-prototype
```
