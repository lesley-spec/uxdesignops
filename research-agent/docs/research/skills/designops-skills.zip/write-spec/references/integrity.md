# Integrity — Define / write-spec

## Gate

- Empathize: designer confirmed problem worth solving (or documented override).
- Define: Designer signs off when happy, then chats with a PM before Ideate. Skills draft; humans approve.

## Verified vs AI

| Label | Meaning |
|---|---|
| **Verified** | Metric/quote/count from linked source or file |
| **AI interpretation** | Framing, clustering, recommended scope — secondary |

## Dual marketplace

Always state **Brand**, **Partner** (creator/affiliate/publisher), or **Shared**. If only one side is evidenced, say so — do not invent the other side’s pain.

## Publish safety

- Create Confluence/Jira only after designer confirms the draft.
- Use Atlassian Rovo MCP (`getJiraIssue`, `search`, `createJiraIssue`, `createConfluencePage`). Do not ask the designer to paste an issue first.
- Prefer aggregate counts and anonymized quotes; no emails/session IDs.
- Mark new pages Document status **DRAFT** until Designer sign-off and PM chat.
